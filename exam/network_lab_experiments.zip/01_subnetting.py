import ipaddress

ip = input("Enter IP address (e.g. 192.168.1.25): ").strip()
prefix_text = input("Enter prefix length [24]: ").strip()
prefix = int(prefix_text) if prefix_text else 24

try:
    interface = ipaddress.ip_interface(f"{ip}/{prefix}")
    network = interface.network

    print("Network address :", network.network_address)
    print("Broadcast address:", network.broadcast_address)

    if network.num_addresses <= 2:
        print("This network has no usable host addresses under the usual IPv4 rules.")
    else:
        print("First usable IP :", network.network_address + 1)
        print("Last usable IP  :", network.broadcast_address - 1)
        print("Usable host count:", network.num_addresses - 2)
except ValueError as error:
    print("Invalid input:", error)
