# Import socket functions so we can create a TCP server.
import socket

# Import threading so each client can be handled independently.
import threading

# Import time so we can pause and simulate receiver processing.
import time

# Import os for safe file names and folder creation.
import os


# Listen on all network interfaces.
HOST = "0.0.0.0"

# Port used by the server and client.
PORT = 5000

# Maximum buffer capacity advertised to the client, in bytes.
BUFFER_SIZE = 4096

# Maximum size of one file chunk, in bytes.
CHUNK_SIZE = 1024

# Simulated time the receiver takes to process each chunk.
PROCESSING_DELAY = 0.25

# Folder where received files will be stored.
SAVE_FOLDER = "received_files"

# Create the folder if it does not already exist.
os.makedirs(SAVE_FOLDER, exist_ok=True)


def receive_file(client, address):
    # Show which client connected.
    print(f"\nClient connected: {address}")

    try:
        # Receive the first message: file name and file size.
        header = client.recv(1024).decode().strip()

        # Split the message into file name and size.
        parts = header.split("|", 1)

        # Reject the request if it does not contain both values.
        if len(parts) != 2:
            client.sendall(b"ERROR|Invalid request")
            return

        # Store the two parts in separate variables.
        filename, size_text = parts

        # Check that the size contains only digits and is not negative.
        if not size_text.isdigit() or int(size_text) < 0:
            client.sendall(b"ERROR|Invalid file size")
            return

        # Remove any directory path so the client cannot choose a save path.
        filename = os.path.basename(filename)

        # Convert the size from text to an integer.
        file_size = int(size_text)

        # Reject an empty file name.
        if not filename:
            client.sendall(b"ERROR|Invalid file name")
            return

        # Add a timestamp to avoid overwriting files with the same name.
        path = os.path.join(
            SAVE_FOLDER, f"{int(time.time() * 1000)}_{filename}"
        )

        # Count how many bytes have arrived so far.
        received = 0

        # Open the destination file in binary-write mode.
        with open(path, "wb") as file:
            # Tell the client that we are ready and advertise buffer capacity.
            client.sendall(f"READY|{BUFFER_SIZE}".encode())

            # Keep receiving data until the declared file size is reached.
            while received < file_size:
                # Read at most one chunk, or the remaining file bytes.
                data = client.recv(min(CHUNK_SIZE, file_size - received))

                # An empty result means the connection closed unexpectedly.
                if not data:
                    print(f"Client disconnected before finishing: {address}")
                    return

                # Write the received bytes to the file.
                file.write(data)

                # Update the total number of bytes received.
                received += len(data)

                # Pause to model the receiver processing the chunk.
                time.sleep(PROCESSING_DELAY)

                # In this simple example, report the configured capacity again.
                free_space = BUFFER_SIZE

                # Acknowledge the total received bytes and advertised capacity.
                client.sendall(f"ACK|{received}|{free_space}".encode())

        # Print a summary after the whole file has arrived.
        print(f"Received {filename} ({received} bytes) from {address}")

        # Tell the user where the received file was saved.
        print(f"Saved as: {path}")

        # Send a final completion message to the client.
        client.sendall(b"DONE")

    # Catch common connection, file-system, and conversion errors.
    except (ConnectionError, OSError, ValueError) as error:
        print(f"Problem with {address}: {error}")

    finally:
        # Always close this client's socket when the function ends.
        client.close()


def main():
    # Create an IPv4 TCP socket.
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Allow the server to reuse the port after a quick restart.
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Attach the socket to the chosen host and port.
    server.bind((HOST, PORT))

    # Start listening for incoming client connections.
    server.listen()

    # Display the server configuration.
    print(f"TCP file receiver listening on {HOST}:{PORT}")
    print(f"Buffer: {BUFFER_SIZE} bytes | Chunk: {CHUNK_SIZE} bytes")
    print("Press Ctrl+C to stop.")

    try:
        # Keep accepting clients until the user stops the server.
        while True:
            # Wait for a client and get its socket and address.
            client, address = server.accept()

            # Start a separate thread so other clients can also connect.
            threading.Thread(
                target=receive_file,
                args=(client, address),
                daemon=True
            ).start()

    # Let Ctrl+C stop the server cleanly.
    except KeyboardInterrupt:
        print("\nServer stopped.")

    finally:
        # Close the listening socket.
        server.close()


# Run main() only when this file is executed directly.
if __name__ == "__main__":
    main()
