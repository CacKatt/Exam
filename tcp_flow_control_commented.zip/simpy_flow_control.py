# Import SimPy, which lets us model processes and simulated time.
import simpy


# Total size of the file to be transferred, in bytes.
FILE_SIZE = 20_000

# Size of each chunk.
CHUNK_SIZE = 1024

# Maximum number of bytes the receiver buffer can hold.
BUFFER_CAPACITY = 4096

# Sender's speed in bytes per second.
SENDER_RATE = 4096

# Receiver's processing speed in bytes per second.
RECEIVER_RATE = 2048

# Simulated network delay for each chunk, in seconds.
NETWORK_DELAY = 0.02


def sender(env, buffer, stats, file_size, chunk_size, buffer_capacity,
           sender_rate, network_delay):
    # Begin with the full file still waiting to be sent.
    bytes_left = file_size

    # Continue until every byte has been sent.
    while bytes_left > 0:
        # The last chunk may be smaller than the normal chunk size.
        size = min(chunk_size, bytes_left)

        # Remember the time before checking whether space is available.
        wait_start = env.now

        # Wait while this chunk would exceed the receiver's buffer capacity.
        while buffer.level + size > buffer_capacity:
            # Advance simulated time by a small amount, then check again.
            yield env.timeout(0.01)

        # Add this buffer-space waiting time to the total.
        stats["sender_wait"] += env.now - wait_start

        # Simulate how long it takes to transmit this chunk.
        yield env.timeout(size / sender_rate)

        # Simulate the time for the chunk to travel across the network.
        yield env.timeout(network_delay)

        # Put the chunk's byte count into the receiver buffer.
        yield buffer.put(size)

        # Update the amount of data sent and the number of chunks.
        bytes_left -= size
        stats["sent_bytes"] += size
        stats["chunks"] += 1

        # Record the current buffer level for a simple average.
        stats["buffer_total"] += buffer.level
        stats["buffer_samples"] += 1


def receiver(env, buffer, stats, file_size, chunk_size, receiver_rate):
    # Continue until the receiver has processed the whole file.
    while stats["received_bytes"] < file_size:
        # Decide how many bytes the receiver should process next.
        size = min(chunk_size, file_size - stats["received_bytes"])

        # Wait until that many bytes are available, then remove them.
        yield buffer.get(size)

        # Simulate the time required to process the bytes.
        yield env.timeout(size / receiver_rate)

        # Count the bytes as processed only after the processing delay.
        stats["received_bytes"] += size
        stats["processed_chunks"] += 1


def run_simulation(buffer_capacity, sender_rate, receiver_rate,
                   file_size=FILE_SIZE):
    # Create a fresh simulated-time environment for this test.
    env = simpy.Environment()

    # Create a buffer that stores a number of bytes, initially empty.
    buffer = simpy.Container(env, capacity=buffer_capacity, init=0)

    # Keep the measurements for this test in one dictionary.
    stats = {
        "sent_bytes": 0,
        "received_bytes": 0,
        "chunks": 0,
        "processed_chunks": 0,
        "sender_wait": 0.0,
        "buffer_total": 0.0,
        "buffer_samples": 0,
    }

    # Start the sender process with the selected configuration.
    env.process(sender(
        env, buffer, stats, file_size, CHUNK_SIZE, buffer_capacity,
        sender_rate, NETWORK_DELAY
    ))

    # Start the receiver process with the selected configuration.
    env.process(receiver(
        env, buffer, stats, file_size, CHUNK_SIZE, receiver_rate
    ))

    # Run until both processes finish.
    env.run()

    # Save the total simulated time needed to complete the transfer.
    total_time = env.now

    # Throughput means bytes transferred divided by elapsed simulated time.
    throughput = file_size / total_time if total_time else 0

    # Calculate the mean of the buffer samples recorded after each send.
    average_buffer = (
        stats["buffer_total"] / stats["buffer_samples"]
        if stats["buffer_samples"] else 0
    )

    # Return the measurements so main() can display them.
    return {
        "buffer_capacity": buffer_capacity,
        "sender_rate": sender_rate,
        "receiver_rate": receiver_rate,
        "completion_time": total_time,
        "throughput": throughput,
        "average_buffer": average_buffer,
        "sender_wait": stats["sender_wait"],
        # Overflow is prevented by checking capacity before every send.
        "overflow_count": 0,
    }


def main():
    # Print a heading for the result table.
    print("TCP receiver-buffer flow-control simulation")
    print("-" * 78)

    # Print the column headings with aligned spacing.
    print(
        f"{'Buffer':>8} {'Send B/s':>10} {'Recv B/s':>10} "
        f"{'Time(s)':>10} {'Throughput':>12} {'Avg buffer':>12} {'Wait(s)':>9}"
    )

    # Each tuple contains: buffer capacity, sender speed, receiver speed.
    tests = [
        (2048, 4096, 1024),
        (4096, 4096, 2048),
        (8192, 8192, 2048),
        (4096, 2048, 4096),
    ]

    # Run the model once for every configuration.
    for capacity, send_rate, recv_rate in tests:
        result = run_simulation(capacity, send_rate, recv_rate)

        # Print the values returned by the simulation.
        print(
            f"{result['buffer_capacity']:>8} "
            f"{result['sender_rate']:>10} "
            f"{result['receiver_rate']:>10} "
            f"{result['completion_time']:>10.2f} "
            f"{result['throughput']:>12.1f} "
            f"{result['average_buffer']:>12.1f} "
            f"{result['sender_wait']:>9.2f}"
        )

    # Explain why this model does not report any overflow.
    print("\nOverflow count is zero because the sender checks buffer space first.")

    # Explain the unit and formula for throughput.
    print("Throughput = file size / simulated completion time (bytes/second).")


# Run main() only when this file is executed directly.
if __name__ == "__main__":
    main()
