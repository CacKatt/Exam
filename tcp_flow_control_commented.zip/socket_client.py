# Import socket functions for TCP communication.
import socket

# Import os to check files and extract a file name.
import os

# Import sys to read the file path from the command line.
import sys


# Server IP address. Use 127.0.0.1 when client and server are on one computer.
SERVER_HOST = "127.0.0.1"

# Port on which the server is listening.
SERVER_PORT = 5000

# Maximum number of bytes sent in one chunk.
CHUNK_SIZE = 1024


def send_file(file_path):
    # Stop if the given path does not point to a file.
    if not os.path.isfile(file_path):
        print("File not found.")
        return

    # Extract only the file name from the supplied path.
    filename = os.path.basename(file_path)

    # Find the file size in bytes.
    file_size = os.path.getsize(file_path)

    # Connect to the server and close the socket automatically afterward.
    with socket.create_connection((SERVER_HOST, SERVER_PORT)) as client:
        # Send the file name and size, separated by a vertical bar.
        client.sendall(f"{filename}|{file_size}".encode())

        # Wait for the server to say READY and advertise its buffer capacity.
        reply = client.recv(1024).decode()

        # Stop if the server did not accept the request.
        if not reply.startswith("READY|"):
            print("Server rejected the request:", reply)
            return

        # Extract the capacity number from the READY message.
        advertised_capacity = int(reply.split("|")[1])

        # Display the receiver's advertised capacity.
        print(f"Server is ready. Advertised buffer: {advertised_capacity} bytes")

        # Track the total number of bytes sent.
        sent = 0

        # Open the source file in binary-read mode.
        with open(file_path, "rb") as file:
            # Continue until all bytes have been sent.
            while sent < file_size:
                # Choose a chunk size that respects both limits and file remainder.
                amount = min(CHUNK_SIZE, advertised_capacity, file_size - sent)

                # Guard against an unusable capacity value.
                if amount <= 0:
                    print("Receiver has no free buffer space; waiting.")
                    continue

                # Read the next chunk from the file.
                chunk = file.read(amount)

                # Stop if there is no more data to read.
                if not chunk:
                    break

                # Send the chunk to the server.
                client.sendall(chunk)

                # Increase the sent-byte counter.
                sent += len(chunk)

                # Wait for the server's acknowledgement before sending more.
                reply = client.recv(1024).decode()

                # Split ACK|received_bytes|free_capacity into separate fields.
                fields = reply.split("|")

                # Check that the server sent an acknowledgement in the expected format.
                if len(fields) != 3 or fields[0] != "ACK":
                    print("Unexpected response from server:", reply)
                    return

                # Read the total received bytes and advertised capacity.
                received = int(fields[1])
                advertised_capacity = int(fields[2])

                # Show progress and the latest advertised capacity.
                print(
                    f"Sent {sent}/{file_size} bytes; "
                    f"receiver confirmed {received}, "
                    f"free buffer {advertised_capacity}"
                )

        # Report whether the whole file was sent.
        if sent == file_size:
            print("File sent successfully.")
        else:
            print(f"Transfer stopped early: sent {sent} of {file_size} bytes.")


# Run this block only when the file is launched directly.
if __name__ == "__main__":
    # A file path must be supplied as a command-line argument.
    if len(sys.argv) != 2:
        print("Usage: python socket_client.py <file_path>")
    else:
        # Pass the supplied path to the sending function.
        send_file(sys.argv[1])
