import socket
import os
import sys

SERVER_HOST = "127.0.0.1"  # Change this to the server computer's IP if needed
SERVER_PORT = 5000
CHUNK_SIZE = 1024


def send_file(file_path):
    if not os.path.isfile(file_path):
        print("File not found.")
        return

    filename = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)

    with socket.create_connection((SERVER_HOST, SERVER_PORT)) as client:
        # Send the file name and size first.
        client.sendall(f"{filename}|{file_size}".encode())

        reply = client.recv(1024).decode()
        if not reply.startswith("READY|"):
            print("Server rejected the request:", reply)
            return

        advertised_capacity = int(reply.split("|")[1])
        print(f"Server is ready. Advertised buffer: {advertised_capacity} bytes")

        sent = 0
        with open(file_path, "rb") as file:
            while sent < file_size:
                # Never send more than one configured chunk or the advertised capacity.
                amount = min(CHUNK_SIZE, advertised_capacity, file_size - sent)
                if amount <= 0:
                    print("Receiver has no free buffer space; waiting.")
                    continue

                chunk = file.read(amount)
                if not chunk:
                    break

                client.sendall(chunk)
                sent += len(chunk)

                # Wait for the receiver's acknowledgement and updated capacity.
                reply = client.recv(1024).decode()
                fields = reply.split("|")
                if len(fields) != 3 or fields[0] != "ACK":
                    print("Unexpected response from server:", reply)
                    return

                received = int(fields[1])
                advertised_capacity = int(fields[2])
                print(
                    f"Sent {sent}/{file_size} bytes; "
                    f"receiver confirmed {received}, free buffer {advertised_capacity}"
                )

        if sent == file_size:
            print("File sent successfully.")
        else:
            print(f"Transfer stopped early: sent {sent} of {file_size} bytes.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python socket_client.py <file_path>")
    else:
        send_file(sys.argv[1])
