import socket
import threading
import time
import os

HOST = "0.0.0.0"
PORT = 5000
BUFFER_SIZE = 4096
CHUNK_SIZE = 1024
PROCESSING_DELAY = 0.25  # Increase this to make the receiver slower
SAVE_FOLDER = "received_files"

os.makedirs(SAVE_FOLDER, exist_ok=True)


def receive_file(client, address):
    print(f"\nClient connected: {address}")

    try:
        # The client first sends the file name and file size.
        header = client.recv(1024).decode().strip()
        parts = header.split("|", 1)
        if len(parts) != 2:
            client.sendall(b"ERROR|Invalid request")
            return

        filename, size_text = parts
        if not size_text.isdigit() or int(size_text) < 0:
            client.sendall(b"ERROR|Invalid file size")
            return

        # Keep only the file name, not any directory path supplied by the client.
        filename = os.path.basename(filename)
        file_size = int(size_text)
        if not filename:
            client.sendall(b"ERROR|Invalid file name")
            return

        path = os.path.join(SAVE_FOLDER, f"{int(time.time() * 1000)}_{filename}")
        received = 0

        with open(path, "wb") as file:
            client.sendall(f"READY|{BUFFER_SIZE}".encode())

            while received < file_size:
                # The client is allowed to send no more than the advertised capacity.
                data = client.recv(min(CHUNK_SIZE, file_size - received))
                if not data:
                    print(f"Client disconnected before finishing: {address}")
                    return

                file.write(data)
                received += len(data)

                # Simulate the receiver processing the data before freeing buffer space.
                time.sleep(PROCESSING_DELAY)
                free_space = BUFFER_SIZE
                client.sendall(f"ACK|{received}|{free_space}".encode())

        print(f"Received {filename} ({received} bytes) from {address}")
        print(f"Saved as: {path}")
        client.sendall(b"DONE")

    except (ConnectionError, OSError, ValueError) as error:
        print(f"Problem with {address}: {error}")
    finally:
        client.close()


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    print(f"TCP file receiver listening on {HOST}:{PORT}")
    print(f"Buffer: {BUFFER_SIZE} bytes | Chunk: {CHUNK_SIZE} bytes")
    print("Press Ctrl+C to stop.")

    try:
        while True:
            client, address = server.accept()
            # One thread lets the server handle multiple clients.
            threading.Thread(
                target=receive_file, args=(client, address), daemon=True
            ).start()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
