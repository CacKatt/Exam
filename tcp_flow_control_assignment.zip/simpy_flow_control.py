import simpy

# Change these values to test different configurations.
FILE_SIZE = 20_000
CHUNK_SIZE = 1024
BUFFER_CAPACITY = 4096
SENDER_RATE = 4096       # Bytes per second
RECEIVER_RATE = 2048     # Bytes per second
NETWORK_DELAY = 0.02     # Seconds per chunk


def sender(env, buffer, stats, file_size, chunk_size, buffer_capacity,
           sender_rate, network_delay):
    bytes_left = file_size

    while bytes_left > 0:
        size = min(chunk_size, bytes_left)

        # Wait until the next chunk can fit in the receiver's buffer.
        wait_start = env.now
        while buffer.level + size > buffer_capacity:
            yield env.timeout(0.01)
        stats["sender_wait"] += env.now - wait_start

        # Simulate transmission and network delay.
        yield env.timeout(size / sender_rate)
        yield env.timeout(network_delay)

        yield buffer.put(size)
        bytes_left -= size
        stats["sent_bytes"] += size
        stats["chunks"] += 1

        # Take a buffer-occupancy sample after each send.
        stats["buffer_total"] += buffer.level
        stats["buffer_samples"] += 1


def receiver(env, buffer, stats, file_size, chunk_size, receiver_rate):
    while stats["received_bytes"] < file_size:
        size = min(chunk_size, file_size - stats["received_bytes"])

        # Wait for a chunk to arrive, then remove it from the buffer.
        yield buffer.get(size)

        # Simulate the time needed to process this chunk.
        yield env.timeout(size / receiver_rate)
        stats["received_bytes"] += size
        stats["processed_chunks"] += 1


def run_simulation(buffer_capacity, sender_rate, receiver_rate, file_size=FILE_SIZE):
    env = simpy.Environment()
    buffer = simpy.Container(env, capacity=buffer_capacity, init=0)

    stats = {
        "sent_bytes": 0,
        "received_bytes": 0,
        "chunks": 0,
        "processed_chunks": 0,
        "sender_wait": 0.0,
        "buffer_total": 0.0,
        "buffer_samples": 0,
    }

    env.process(sender(
        env, buffer, stats, file_size, CHUNK_SIZE, buffer_capacity,
        sender_rate, NETWORK_DELAY
    ))
    env.process(receiver(
        env, buffer, stats, file_size, CHUNK_SIZE, receiver_rate
    ))
    env.run()

    total_time = env.now
    throughput = file_size / total_time if total_time else 0
    average_buffer = (
        stats["buffer_total"] / stats["buffer_samples"]
        if stats["buffer_samples"] else 0
    )

    return {
        "buffer_capacity": buffer_capacity,
        "sender_rate": sender_rate,
        "receiver_rate": receiver_rate,
        "completion_time": total_time,
        "throughput": throughput,
        "average_buffer": average_buffer,
        "sender_wait": stats["sender_wait"],
        "overflow_count": 0,
    }


def main():
    print("TCP receiver-buffer flow-control simulation")
    print("-" * 78)
    print(
        f"{'Buffer':>8} {'Send B/s':>10} {'Recv B/s':>10} "
        f"{'Time(s)':>10} {'Throughput':>12} {'Avg buffer':>12} {'Wait(s)':>9}"
    )

    # Each row is: buffer capacity, sender rate, receiver rate.
    tests = [
        (2048, 4096, 1024),
        (4096, 4096, 2048),
        (8192, 8192, 2048),
        (4096, 2048, 4096),
    ]

    for capacity, send_rate, recv_rate in tests:
        result = run_simulation(capacity, send_rate, recv_rate)
        print(
            f"{result['buffer_capacity']:>8} "
            f"{result['sender_rate']:>10} "
            f"{result['receiver_rate']:>10} "
            f"{result['completion_time']:>10.2f} "
            f"{result['throughput']:>12.1f} "
            f"{result['average_buffer']:>12.1f} "
            f"{result['sender_wait']:>9.2f}"
        )

    print("\nOverflow count is zero because the sender checks buffer space first.")
    print("Throughput = file size / simulated completion time (bytes/second).")


if __name__ == "__main__":
    main()
