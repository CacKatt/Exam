# socket is used to connect to the TCP server; json formats the message.
import socket
import json

# Use localhost when both programs run on the same computer.
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5001


def fold_sum(words):
    # Add the word values.
    total = sum(words)

    # Add carry bits back into the low 8 bits until none remain.
    while total > 255:
        total = (total & 255) + (total >> 8)
    return total


def make_checksum(words):
    # One's-complement checksum is the bitwise inverse of the folded sum.
    return (~fold_sum(words)) & 255


def valid_word(word):
    # Accept exactly eight binary digits and reject all other input.
    return (
        isinstance(word, str)
        and len(word) == 8
        and all(bit in "01" for bit in word)
    )


def read_words():
    # Collect three valid 8-bit data words from the user.
    words = []
    for number in range(1, 4):
        while True:
            word = input(f"Enter 8-bit data word {number}: ").strip()
            if valid_word(word):
                words.append(word)
                break
            print("Invalid input. Enter exactly 8 bits, using only 0 and 1.")
    return words


def flip_bit(word, position):
    # Convert the binary string into a list so one bit can be changed.
    bits = list(word)

    # Change 0 to 1 or 1 to 0 at the selected position.
    bits[position] = "1" if bits[position] == "0" else "0"
    return "".join(bits)


def make_packet(words):
    # Convert the three binary strings into numbers.
    values = [int(word, 2) for word in words]

    # Return the data words and checksum in a JSON-friendly dictionary.
    return {"words": words, "checksum": f"{make_checksum(values):08b}"}


def talk_to_server(packet, raw_text=None):
    # Open a TCP connection; the context manager closes it afterward.
    with socket.create_connection((SERVER_HOST, SERVER_PORT), timeout=5) as client:
        # Normal tests send JSON; the incomplete-message test sends raw text.
        if raw_text is None:
            message = json.dumps(packet)
        else:
            message = raw_text

        # A newline marks the end of one application-level message.
        client.sendall((message + "\n").encode("utf-8"))

        # Read the server's one-line JSON response.
        reply = client.makefile("r", encoding="utf-8").readline()
        if not reply:
            print("The server closed the connection without a reply.")
            return
        print("Server response:", json.loads(reply))


def main():
    # Ask the user for three sensor readings as binary words.
    print("Sensor Data Checksum Client")
    words = read_words()

    # Calculate the checksum before sending the message.
    packet = make_packet(words)
    print("\nOriginal data words:", words)
    print("Calculated checksum:", packet["checksum"])

    # Let the user choose a normal transfer or an error test.
    print("\nChoose a test:")
    print("1. Send a valid message")
    print("2. Flip one data bit")
    print("3. Flip multiple data bits")
    print("4. Send invalid binary data")
    print("5. Send an incomplete message")
    choice = input("Your choice: ").strip()

    if choice == "1":
        # Send the original words with their correct checksum.
        talk_to_server(packet)

    elif choice == "2":
        # Change one bit but keep the original checksum, simulating corruption.
        changed = words.copy()
        changed[0] = flip_bit(changed[0], 0)
        talk_to_server({"words": changed, "checksum": packet["checksum"]})

    elif choice == "3":
        # Change two data bits but keep the old checksum.
        changed = words.copy()
        changed[0] = flip_bit(changed[0], 0)
        changed[1] = flip_bit(changed[1], 2)
        talk_to_server({"words": changed, "checksum": packet["checksum"]})

    elif choice == "4":
        # Deliberately include characters other than 0 and 1.
        invalid_packet = {
            "words": ["01010101", "01012A01", words[2]],
            "checksum": packet["checksum"]
        }
        talk_to_server(invalid_packet)

    elif choice == "5":
        # Send incomplete JSON to test the receiver's malformed-message check.
        talk_to_server({}, raw_text='{"words":["01010101","01010110"')

    else:
        # Tell the user how to choose a supported test.
        print("Unknown choice. Run the client again and choose 1 to 5.")


# Run the menu only when the file is executed directly.
if __name__ == "__main__":
    # Start the interactive client.
    main()
