# random creates sensor readings and simulates transmission bit errors.
import random

# SimPy provides simulated time, processes, and queues.
import simpy

# The model uses at least five sensor nodes, as required.
SENSOR_COUNT = 5

# Each message has three 8-bit data words.
WORDS_PER_MESSAGE = 3
WORD_BITS = 8

# Stop the simulated experiment after this many seconds.
SIMULATION_TIME = 30

# Delay between sending and the channel delivering a message.
CHANNEL_DELAY = 0.15

# Time the monitoring server takes to verify a message.
PROCESSING_DELAY = 0.02


def fold_sum(values):
    # Add all 8-bit word values.
    total = sum(values)

    # Fold carry bits back into the lowest 8 bits.
    while total > 255:
        total = (total & 255) + (total >> 8)
    return total


def make_checksum(values):
    # Invert the folded sum to create the 8-bit one's-complement checksum.
    return (~fold_sum(values)) & 255


def packet_is_valid(values, checksum):
    # A correct message plus its checksum must fold to 11111111 (255).
    return fold_sum(values + [checksum]) == 255


def flip_random_bits(values, checksum, error_probability):
    # Work on a copy so the original sender data stays unchanged.
    changed = values.copy()
    changed_checksum = checksum

    # Count the number of flipped bits in data and checksum.
    flips = 0

    # Check every bit in every data word independently.
    for word_index in range(len(changed)):
        value = changed[word_index]
        for bit in range(WORD_BITS):
            if random.random() < error_probability:
                # XOR with a one-bit mask toggles the selected bit.
                value ^= 1 << bit
                flips += 1
        changed[word_index] = value

    # Transmission errors can also affect the checksum byte.
    for bit in range(WORD_BITS):
        if random.random() < error_probability:
            changed_checksum ^= 1 << bit
            flips += 1

    # Return the possibly corrupted data, checksum, and number of flipped bits.
    return changed, changed_checksum, flips


def sensor(env, sensor_id, channel, stats, generation_interval, error_probability):
    # Each sensor keeps generating messages during the simulation.
    while True:
        # Wait until it is time for the next sensor reading.
        yield env.timeout(generation_interval)

        # Generate three random 8-bit readings (0 through 255).
        values = [random.randint(0, 255) for _ in range(WORDS_PER_MESSAGE)]

        # Calculate the checksum before the message enters the channel.
        checksum = make_checksum(values)

        # Record the simulated send time for delay calculation.
        sent_at = env.now

        # Update the generated and transmitted message counters.
        stats["generated"] += 1
        stats["transmitted"] += 1

        # Store all information needed by the channel and receiver.
        message = {
            "sensor_id": sensor_id,
            "values": values,
            "checksum": checksum,
            "sent_at": sent_at,
            "error_probability": error_probability,
        }

        # Put the message into the shared channel queue.
        yield channel.put(message)


def channel_and_server(env, channel, stats, error_probability):
    # This process takes messages from the queue one at a time.
    while True:
        message = yield channel.get()

        # Wait to model transmission delay.
        yield env.timeout(CHANNEL_DELAY)

        # Save the original data and checksum from the sensor.
        original_values = message["values"]
        original_checksum = message["checksum"]

        # Simulate random bit errors during transmission.
        received_values, received_checksum, flips = flip_random_bits(
            original_values, original_checksum, error_probability
        )

        # Count a message as corrupted if at least one bit flipped.
        if flips > 0:
            stats["corrupted"] += 1

        # Simulate the server's checksum processing time.
        yield env.timeout(PROCESSING_DELAY)

        # Check the received words and checksum.
        valid = packet_is_valid(received_values, received_checksum)

        if valid:
            # A message that passes the checksum is accepted.
            stats["received_valid"] += 1
            stats["delivered"] += 1

            # If bits changed but the checksum passed, the error went undetected.
            if flips > 0:
                stats["undetected"] += 1
        else:
            # Reject a message when its checksum does not pass.
            stats["rejected"] += 1

        # Add end-to-end simulated time for this message.
        stats["total_delay"] += env.now - message["sent_at"]


def run_scenario(name, generation_interval, error_probability, seed):
    # Use a repeatable random seed so each scenario can be reproduced.
    random.seed(seed)

    # Create the simulation clock and a FIFO queue for messages.
    env = simpy.Environment()
    channel = simpy.Store(env)

    # Initialise the counters and delay total for this scenario.
    stats = {
        "generated": 0,
        "transmitted": 0,
        "corrupted": 0,
        "received_valid": 0,
        "delivered": 0,
        "rejected": 0,
        "undetected": 0,
        "total_delay": 0.0,
    }

    # Start five independent sensor processes.
    for sensor_id in range(1, SENSOR_COUNT + 1):
        env.process(sensor(
            env, sensor_id, channel, stats,
            generation_interval, error_probability
        ))

    # Start the shared communication channel and monitoring server.
    env.process(channel_and_server(env, channel, stats, error_probability))

    # Run the simulation until the configured stopping time.
    env.run(until=SIMULATION_TIME)

    # Calculate useful performance measurements without dividing by zero.
    generated = stats["generated"]
    delivered = stats["delivered"]
    rejected = stats["rejected"]
    average_delay = (
        stats["total_delay"] / (delivered + rejected)
        if delivered + rejected else 0
    )
    delivery_ratio = delivered / generated if generated else 0
    detection_rate = (
        rejected / stats["corrupted"] if stats["corrupted"] else 0
    )

    # Return the values needed for the final comparison table.
    return {
        "name": name,
        "generated": generated,
        "transmitted": stats["transmitted"],
        "corrupted": stats["corrupted"],
        "delivered": delivered,
        "rejected": rejected,
        "undetected": stats["undetected"],
        "delivery_ratio": delivery_ratio,
        "detection_rate": detection_rate,
        "average_delay": average_delay,
    }


def main():
    # Print the model settings.
    print("Sensor checksum simulation")
    print(f"Sensors: {SENSOR_COUNT}, simulation time: {SIMULATION_TIME}s")
    print("Each message contains three 8-bit words plus an 8-bit checksum.\n")

    # Compare low/high bit-error probabilities and slower/faster generation.
    scenarios = [
        ("Low errors, slower generation", 2.0, 0.001, 10),
        ("High errors, slower generation", 2.0, 0.05, 20),
        ("Low errors, faster generation", 0.5, 0.001, 30),
        ("High errors, faster generation", 0.5, 0.05, 40),
    ]

    # Run all four scenarios and collect their results.
    results = []
    for name, interval, error_probability, seed in scenarios:
        results.append(run_scenario(name, interval, error_probability, seed))

    # Print the headings for the comparison table.
    print(
        f"{'Scenario':32} {'Gen.':>5} {'Corrupt':>8} {'Delivered':>10} "
        f"{'Rejected':>9} {'Undetected':>11} {'Delivery%':>10} "
        f"{'Detect%':>8} {'Avg delay':>10}"
    )

    # Display each scenario's measurements.
    for result in results:
        print(
            f"{result['name']:32} "
            f"{result['generated']:>5} "
            f"{result['corrupted']:>8} "
            f"{result['delivered']:>10} "
            f"{result['rejected']:>9} "
            f"{result['undetected']:>11} "
            f"{100 * result['delivery_ratio']:>9.1f}% "
            f"{100 * result['detection_rate']:>7.1f}% "
            f"{result['average_delay']:>9.3f}s"
        )

    # Explain how to interpret the simulation.
    print("\nNotes:")
    print("- Error probability is applied independently to every transmitted bit.")
    print("- Undetected means at least one bit flipped but the checksum still passed.")
    print("- This checksum can miss some multiple-bit error patterns.")
    print("- The channel is a single FIFO queue, so faster generation can add waiting.")


# Run the experiment only when this file is launched directly.
if __name__ == "__main__":
    main()
