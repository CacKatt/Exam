# socket provides TCP networking; threading lets the server handle multiple clients.
import socket
import threading

# json converts structured Python data to a message that can be sent over TCP.
import json

# Listen on every network interface, on TCP port 5001.
HOST = "0.0.0.0"
PORT = 5001


def fold_sum(words):
    # Add the 8-bit values together.
    total = sum(words)

    # Fold any carry bits back into the low 8 bits (one's-complement addition).
    while total > 255:
        total = (total & 255) + (total >> 8)

    # Return the final 8-bit sum.
    return total


def make_checksum(words):
    # Flip all bits of the folded sum to get the one's-complement checksum.
    return (~fold_sum(words)) & 255


def valid_word(word):
    # A valid word must be text, exactly 8 characters long, containing only 0/1.
    return (
        isinstance(word, str)
        and len(word) == 8
        and all(bit in "01" for bit in word)
    )


def check_packet(packet):
    # Reject data that is not a JSON object.
    if not isinstance(packet, dict):
        return False, "Message must be a JSON object."

    # Read the three data words and the checksum from the message.
    words = packet.get("words")
    checksum = packet.get("checksum")

    # The assignment requires exactly three data words.
    if not isinstance(words, list) or len(words) != 3:
        return False, "Message must contain exactly three data words."

    # Validate the format of each 8-bit data word.
    if not all(valid_word(word) for word in words):
        return False, "One or more data words are not valid 8-bit binary strings."

    # Validate the checksum's format too.
    if not isinstance(checksum, str) or not valid_word(checksum):
        return False, "Checksum must be an 8-bit binary string."

    # Convert binary text into integer values for arithmetic.
    values = [int(word, 2) for word in words]
    received_checksum = int(checksum, 2)

    # Calculate what the checksum should be for the received data.
    expected_checksum = make_checksum(values)

    # If the received checksum differs, the data fails verification.
    if received_checksum != expected_checksum:
        return False, (
            f"Checksum mismatch: received {checksum}, "
            f"expected {expected_checksum:08b}."
        )

    # A valid data-plus-checksum sum should fold to all 1 bits (255).
    if fold_sum(values + [received_checksum]) != 255:
        return False, "One's-complement verification failed."

    # Both checks passed.
    return True, "Message is valid; checksum passed."


def handle_client(client, address):
    # Print the client's address for testing and debugging.
    print(f"\nConnected: {address}")
    try:
        # 'with client' ensures this connection is closed when handling ends.
        with client:
            # Treat the TCP stream as newline-separated text messages.
            file = client.makefile("r", encoding="utf-8")
            for line in file:
                # Remove whitespace and the newline at the end.
                line = line.strip()
                if not line:
                    continue

                try:
                    # Parse one line of JSON into a Python object.
                    packet = json.loads(line)

                    # Verify the data words and checksum on the receiver side.
                    ok, message = check_packet(packet)
                    print(f"Received from {address}: {packet}")
                    print(f"Result: {message}")

                    # Prepare the result for the client.
                    reply = {"valid": ok, "message": message}
                except json.JSONDecodeError:
                    # Malformed or incomplete JSON is rejected.
                    print(f"Received an invalid or incomplete message from {address}.")
                    reply = {
                        "valid": False,
                        "message": "Invalid or incomplete JSON message."
                    }

                # Send one JSON response line back to the client.
                client.sendall((json.dumps(reply) + "\n").encode("utf-8"))
    except (ConnectionError, OSError) as error:
        # Report connection problems without crashing the whole server.
        print(f"Connection problem with {address}: {error}")
    finally:
        # Log that this client handler has finished.
        print(f"Disconnected: {address}")


def main():
    # Create an IPv4 TCP socket.
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Allow quick restart without waiting for the port to time out.
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Bind the server to the configured host and port.
    server.bind((HOST, PORT))

    # Begin listening for client connections.
    server.listen()
    print(f"Sensor monitoring server listening on {HOST}:{PORT}")
    print("Press Ctrl+C to stop.")
    try:
        # Keep accepting clients until the user stops the program.
        while True:
            client, address = server.accept()

            # Handle each client in a separate thread.
            threading.Thread(
                target=handle_client,
                args=(client, address),
                daemon=True
            ).start()
    except KeyboardInterrupt:
        # Allow a clean shutdown with Ctrl+C.
        print("\nServer stopped.")
    finally:
        # Release the listening socket.
        server.close()


# Start the server only when this file is run directly.
if __name__ == "__main__":
    main()
