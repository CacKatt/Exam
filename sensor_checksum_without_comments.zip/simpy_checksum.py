import random
import simpy

SENSOR_COUNT = 5
WORDS_PER_MESSAGE = 3
WORD_BITS = 8
SIMULATION_TIME = 30
CHANNEL_DELAY = 0.15
PROCESSING_DELAY = 0.02


def fold_sum(values):
    total = sum(values)
    while total > 255:
        total = (total & 255) + (total >> 8)
    return total


def make_checksum(values):
    return (~fold_sum(values)) & 255


def packet_is_valid(values, checksum):
    return fold_sum(values + [checksum]) == 255


def flip_random_bits(values, checksum, error_probability):
    changed = values.copy()
    changed_checksum = checksum
    flips = 0

    for word_index in range(len(changed)):
        value = changed[word_index]
        for bit in range(WORD_BITS):
            if random.random() < error_probability:
                value ^= 1 << bit
                flips += 1
        changed[word_index] = value

    for bit in range(WORD_BITS):
        if random.random() < error_probability:
            changed_checksum ^= 1 << bit
            flips += 1

    return changed, changed_checksum, flips


def sensor(env, sensor_id, channel, stats, generation_interval, error_probability):
    while True:
        yield env.timeout(generation_interval)

        values = [random.randint(0, 255) for _ in range(WORDS_PER_MESSAGE)]
        checksum = make_checksum(values)
        sent_at = env.now

        stats["generated"] += 1
        stats["transmitted"] += 1

        message = {
            "sensor_id": sensor_id,
            "values": values,
            "checksum": checksum,
            "sent_at": sent_at,
            "error_probability": error_probability,
        }
        yield channel.put(message)


def channel_and_server(env, channel, stats, error_probability):
    while True:
        message = yield channel.get()
        yield env.timeout(CHANNEL_DELAY)

        original_values = message["values"]
        original_checksum = message["checksum"]
        received_values, received_checksum, flips = flip_random_bits(
            original_values, original_checksum, error_probability
        )

        if flips > 0:
            stats["corrupted"] += 1

        yield env.timeout(PROCESSING_DELAY)

        valid = packet_is_valid(received_values, received_checksum)
        if valid:
            stats["received_valid"] += 1
            stats["delivered"] += 1
            if flips > 0:
                stats["undetected"] += 1
        else:
            stats["rejected"] += 1

        stats["total_delay"] += env.now - message["sent_at"]


def run_scenario(name, generation_interval, error_probability, seed):
    random.seed(seed)
    env = simpy.Environment()
    channel = simpy.Store(env)
    stats = {
        "generated": 0,
        "transmitted": 0,
        "corrupted": 0,
        "received_valid": 0,
        "delivered": 0,
        "rejected": 0,
        "undetected": 0,
        "total_delay": 0.0,
    }

    for sensor_id in range(1, SENSOR_COUNT + 1):
        env.process(sensor(
            env, sensor_id, channel, stats,
            generation_interval, error_probability
        ))

    env.process(channel_and_server(env, channel, stats, error_probability))
    env.run(until=SIMULATION_TIME)

    generated = stats["generated"]
    delivered = stats["delivered"]
    rejected = stats["rejected"]
    average_delay = (
        stats["total_delay"] / (delivered + rejected)
        if delivered + rejected else 0
    )
    delivery_ratio = delivered / generated if generated else 0
    detection_rate = (
        rejected / stats["corrupted"] if stats["corrupted"] else 0
    )

    return {
        "name": name,
        "generated": generated,
        "transmitted": stats["transmitted"],
        "corrupted": stats["corrupted"],
        "delivered": delivered,
        "rejected": rejected,
        "undetected": stats["undetected"],
        "delivery_ratio": delivery_ratio,
        "detection_rate": detection_rate,
        "average_delay": average_delay,
    }


def main():
    print("Sensor checksum simulation")
    print(f"Sensors: {SENSOR_COUNT}, simulation time: {SIMULATION_TIME}s")
    print("Each message contains three 8-bit words plus an 8-bit checksum.\n")

    scenarios = [
        ("Low errors, slower generation", 2.0, 0.001, 10),
        ("High errors, slower generation", 2.0, 0.05, 20),
        ("Low errors, faster generation", 0.5, 0.001, 30),
        ("High errors, faster generation", 0.5, 0.05, 40),
    ]

    results = []
    for name, interval, error_probability, seed in scenarios:
        results.append(run_scenario(name, interval, error_probability, seed))

    print(
        f"{'Scenario':32} {'Gen.':>5} {'Corrupt':>8} {'Delivered':>10} "
        f"{'Rejected':>9} {'Undetected':>11} {'Delivery%':>10} "
        f"{'Detect%':>8} {'Avg delay':>10}"
    )

    for result in results:
        print(
            f"{result['name']:32} "
            f"{result['generated']:>5} "
            f"{result['corrupted']:>8} "
            f"{result['delivered']:>10} "
            f"{result['rejected']:>9} "
            f"{result['undetected']:>11} "
            f"{100 * result['delivery_ratio']:>9.1f}% "
            f"{100 * result['detection_rate']:>7.1f}% "
            f"{result['average_delay']:>9.3f}s"
        )

    print("\nNotes:")
    print("- Error probability is applied independently to every transmitted bit.")
    print("- Undetected means at least one bit flipped but the checksum still passed.")
    print("- This checksum can miss some multiple-bit error patterns.")
    print("- The channel is a single FIFO queue, so faster generation can add waiting.")


if __name__ == "__main__":
    main()
