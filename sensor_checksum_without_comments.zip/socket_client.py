import socket
import json

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5001


def fold_sum(words):
    total = sum(words)
    while total > 255:
        total = (total & 255) + (total >> 8)
    return total


def make_checksum(words):
    return (~fold_sum(words)) & 255


def valid_word(word):
    return (
        isinstance(word, str)
        and len(word) == 8
        and all(bit in "01" for bit in word)
    )


def read_words():
    words = []
    for number in range(1, 4):
        while True:
            word = input(f"Enter 8-bit data word {number}: ").strip()
            if valid_word(word):
                words.append(word)
                break
            print("Invalid input. Enter exactly 8 bits, using only 0 and 1.")
    return words


def flip_bit(word, position):
    bits = list(word)
    bits[position] = "1" if bits[position] == "0" else "0"
    return "".join(bits)


def make_packet(words):
    values = [int(word, 2) for word in words]
    return {"words": words, "checksum": f"{make_checksum(values):08b}"}


def talk_to_server(packet, raw_text=None):
    with socket.create_connection((SERVER_HOST, SERVER_PORT), timeout=5) as client:
        if raw_text is None:
            message = json.dumps(packet)
        else:
            message = raw_text
        client.sendall((message + "\n").encode("utf-8"))
        reply = client.makefile("r", encoding="utf-8").readline()
        if not reply:
            print("The server closed the connection without a reply.")
            return
        print("Server response:", json.loads(reply))


def main():
    print("Sensor Data Checksum Client")
    words = read_words()
    packet = make_packet(words)

    print("\nOriginal data words:", words)
    print("Calculated checksum:", packet["checksum"])
    print("\nChoose a test:")
    print("1. Send a valid message")
    print("2. Flip one data bit")
    print("3. Flip multiple data bits")
    print("4. Send invalid binary data")
    print("5. Send an incomplete message")

    choice = input("Your choice: ").strip()

    if choice == "1":
        talk_to_server(packet)

    elif choice == "2":
        changed = words.copy()
        changed[0] = flip_bit(changed[0], 0)
        talk_to_server({"words": changed, "checksum": packet["checksum"]})

    elif choice == "3":
        changed = words.copy()
        changed[0] = flip_bit(changed[0], 0)
        changed[1] = flip_bit(changed[1], 2)
        talk_to_server({"words": changed, "checksum": packet["checksum"]})

    elif choice == "4":
        invalid_packet = {
            "words": ["01010101", "01012A01", words[2]],
            "checksum": packet["checksum"]
        }
        talk_to_server(invalid_packet)

    elif choice == "5":
        talk_to_server({}, raw_text='{"words":["01010101","01010110"')

    else:
        print("Unknown choice. Run the client again and choose 1 to 5.")


if __name__ == "__main__":
    main()
