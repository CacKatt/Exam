import socket
import json
import threading

HOST = "0.0.0.0"
PORT = 5001


def fold_sum(words):
    total = sum(words)
    while total > 255:
        total = (total & 255) + (total >> 8)
    return total


def make_checksum(words):
    return (~fold_sum(words)) & 255


def valid_word(word):
    return (
        isinstance(word, str)
        and len(word) == 8
        and all(bit in "01" for bit in word)
    )


def check_packet(packet):
    if not isinstance(packet, dict):
        return False, "Message must be a JSON object."

    words = packet.get("words")
    checksum = packet.get("checksum")

    if not isinstance(words, list) or len(words) != 3:
        return False, "Message must contain exactly three data words."

    if not all(valid_word(word) for word in words):
        return False, "One or more data words are not valid 8-bit binary strings."

    if not isinstance(checksum, str) or not valid_word(checksum):
        return False, "Checksum must be an 8-bit binary string."

    values = [int(word, 2) for word in words]
    received_checksum = int(checksum, 2)
    expected_checksum = make_checksum(values)

    if received_checksum != expected_checksum:
        return False, (
            f"Checksum mismatch: received {checksum}, "
            f"expected {expected_checksum:08b}."
        )

    if fold_sum(values + [received_checksum]) != 255:
        return False, "One's-complement verification failed."

    return True, "Message is valid; checksum passed."


def handle_client(client, address):
    print(f"\nConnected: {address}")
    try:
        with client:
            file = client.makefile("r", encoding="utf-8")
            for line in file:
                line = line.strip()
                if not line:
                    continue
                try:
                    packet = json.loads(line)
                    ok, message = check_packet(packet)
                    print(f"Received from {address}: {packet}")
                    print(f"Result: {message}")
                    reply = {"valid": ok, "message": message}
                except json.JSONDecodeError:
                    print(f"Received an invalid or incomplete message from {address}.")
                    reply = {
                        "valid": False,
                        "message": "Invalid or incomplete JSON message."
                    }
                client.sendall((json.dumps(reply) + "\n").encode("utf-8"))
    except (ConnectionError, OSError) as error:
        print(f"Connection problem with {address}: {error}")
    finally:
        print(f"Disconnected: {address}")


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    print(f"Sensor monitoring server listening on {HOST}:{PORT}")
    print("Press Ctrl+C to stop.")
    try:
        while True:
            client, address = server.accept()
            threading.Thread(
                target=handle_client,
                args=(client, address),
                daemon=True
            ).start()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
